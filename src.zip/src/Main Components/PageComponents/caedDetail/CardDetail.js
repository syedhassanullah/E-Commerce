import React from 'react'

export const CardDetail = () => {
  return (
    <h1>Card Detail One by One</h1>
  )
}
