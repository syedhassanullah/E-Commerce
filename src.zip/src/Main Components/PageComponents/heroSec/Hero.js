import React from 'react';
import './Hero.css';
import hero2 from '../../imgs/hero2.png'

export const Hero = () => {
  return (
    <>
    <div className='hero'>
        <div className='hero1'>
        </div>
        <div className='hero2'>
            
        </div>
        <div className='hero3'>
        <img src={hero2} alt="img"/>
        </div>
    </div>
    </>
  )
}

export default Hero