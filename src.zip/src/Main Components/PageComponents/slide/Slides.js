import React from 'react'

import './Slides.css';


const Slides = () => {
  return (
    <section className='slidemain'>
        <div className='slide1'></div>
        <div className='slide2'></div>
    </section>
  )
}


export default Slides